<?php
session_start();
require_once 'includes/functions.php';
redirect_if_not_logged_in();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['patient_id'])) {
    // Handle patient removal
    $patient_id = $_POST['patient_id'];

    // Remove the patient from the database
    require_once 'includes/db.php';

    $sql = "DELETE FROM patients WHERE patient_id = $patient_id";

    if ($conn->query($sql) === TRUE) {
        echo "Patient removed successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Remove Patient</title>
    <link rel="stylesheet" type="text/css" href="assets/style.css">
</head>
<body>
    <h1>Remove Patient</h1>

    <form action="RemovePatient.php" method="POST">
        <label for="patient_id">Patient ID:</label>
        <input type="number" name="patient_id" required><br>

        <input type="submit" value="Remove Patient">
    </form>

    <a href="index.php">Back to Homepage</a>
</body>
</html>
