<?php
session_start();
require_once 'includes/functions.php';
redirect_if_not_logged_in();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle patient registration form submission

    // Extract patient data from the form
    $patient_name = $_POST['patient_name'];
    $patient_age = $_POST['patient_age'];
    $patient_gender = $_POST['patient_gender'];
    $patient_address = $_POST['patient_address'];
    $patient_phone = $_POST['patient_phone'];
    $admission_date = $_POST['admission_date'];
    $discharge_date = $_POST['discharge_date'];
    $diagnosis = $_POST['diagnosis'];
    $treatment = $_POST['treatment'];

    // Insert the patient data into the database
    require_once 'includes/db.php';

    $sql = "INSERT INTO patients (patient_name, patient_age, patient_gender, patient_address, patient_phone, admission_date, discharge_date, diagnosis, treatment)
            VALUES ('$patient_name', $patient_age, '$patient_gender', '$patient_address', '$patient_phone', '$admission_date', '$discharge_date', '$diagnosis', '$treatment')";

    if ($conn->query($sql) === TRUE) {
        echo "Patient added successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Patient</title>
    <link rel="stylesheet" type="text/css" href="assets/style.css">
</head>
<body>
    <h1>Add Patient</h1>

    <form action="AddPatient.php" method="POST">
        <label for="patient_name">Patient Name:</label>
        <input type="text" name="patient_name" required><br>

        <label for="patient_age">Age:</label>
        <input type="number" name="patient_age" required><br>

        <label for="patient_gender">Gender:</label>
        <select name="patient_gender">
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
        </select><br>

        <label for="patient_address">Address:</label>
        <input type="text" name="patient_address"><br>

        <label for="patient_phone">Phone:</label>
        <input type="text" name="patient_phone"><br>

        <label for="admission_date">Admission Date:</label>
        <input type="date" name="admission_date"><br>

        <label for="discharge_date">Discharge Date:</label>
        <input type="date" name="discharge_date"><br>

        <label for="diagnosis">Diagnosis:</label>
        <input type="text" name="diagnosis"><br>

        <label for="treatment">Treatment:</label>
        <input type="text" name="treatment"><br>

        <input type="submit" value="Add Patient">
    </form>

    <a href="index.php">Back to Homepage</a>
</body>
</html>
