<?php
$servername = "127.0.0.1:3308";
$username = "oyo3";
$password = "oyo3";
$dbname = "hmproject";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
