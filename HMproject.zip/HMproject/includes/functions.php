<?php
function is_logged_in() {
    return isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true;
}

function redirect_if_not_logged_in() {
    if (!is_logged_in()) {
        header("Location: Login.php");
        exit;
    }
}
?>
