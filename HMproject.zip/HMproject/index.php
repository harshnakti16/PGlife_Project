<?php
session_start();
require_once 'includes/functions.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Hospital Management System</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h1>Welcome to Our Hospital</h1>
     
    <h2>Patients:</h2>
    <ul>
        <!-- Display patient information -->
        <?php
        require_once 'includes/db.php';

        $sql = "SELECT * FROM patients";
        $result = $conn->query($sql);

        if ($result === false) {
            die("Error: " . $conn->error);
        }

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<li>Patient: " . $row["patient_name"] . " - Age: " . $row["patient_age"] . "</li>";
            }
        } else {
            echo "No patients available.";
        }

        $conn->close();
        ?>
    </ul>

    <?php if (is_logged_in()) : ?>
        <a href="AddPatient.php">Add a Patient</a><br>
        <a href="RemovePatient.php">Remove a Patient</a><br>
        <a href="AddMedicineDetail.php">Add Medicine</a><br>
        <a href="AboutUs.php">About Us</a>
    <?php else : ?>
        <a href="Login.php">Login</a>
    <?php endif; ?>
</body>
</html>
