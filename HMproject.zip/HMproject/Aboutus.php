<!DOCTYPE html>
<html>
<head>
    <title>About Us</title>
    <link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
    <h1>About Us</h1>
    <p>This is the About Us page for our hospital management system.Welcome to the Hospital Management System (HMS), a leading healthcare technology solution designed to streamline hospital operations and enhance patient care. 
        At HMS, we are committed to revolutionizing the way healthcare institutions manage their daily activities, from patient records and appointments to billing and beyond.<br>
        
        
        We'd love to hear from you and answer any questions you may have. 
        Please feel free to reach out to us:<br>
        <b>Address: 123 Hospital Street, City, Country<b><br>
        <b>Phone: (123) 456-7890<b><br>
        <b>Email: info@hospitalmanagement.com<b><br>
</p>

    <a href="index.php">Back to Homepage</a>
</body>
</html>
