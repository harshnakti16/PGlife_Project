<?php
session_start();
require_once 'includes/functions.php';
redirect_if_not_logged_in();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle adding medicine details
    $medicine_name = $_POST['medicine_name'];
    $description = $_POST['description'];

    // Insert medicine details into the database
    require_once 'includes/db.php';

    $sql = "INSERT INTO medicines (medicine_name, description)
            VALUES ('$medicine_name', '$description')";

    if ($conn->query($sql) === TRUE) {
        echo "Medicine details added successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Medicine Detail</title>
    <link rel="stylesheet" type="text/css" href="assets/style.css">
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h1>Add Medicine Detail</h1>
    


    <form action="AddMedicineDetail.php" method="POST">
        <label for="medicine_name">Medicine Name:</label>
        <input type="text" name="medicine_name" required><br>

        <label for="description">Description:</label>
        <textarea name="description" rows="4" cols="50" required></textarea><br>

        <input type="submit" value="Add Medicine Detail">
    </form>

    <a href="index.php">Back to Homepage</a>
</body>
</html>
